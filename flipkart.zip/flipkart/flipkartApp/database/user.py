from django.db import models

class Customer(models.Model):
    name=models.CharField(max_length=30)
    password=models.CharField(max_length=15)
    email=models.EmailField()
    mobile=models.IntegerField(default=0,null=True)

    def register(self):
        return self.save()
    @staticmethod
    def login_user(email,password):
        return Customer.objects.filter(email=email,password=password)


