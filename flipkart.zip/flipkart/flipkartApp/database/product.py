from django.db import models
from .category import Category_flipkart

class Product_flipkart(models.Model):
    name=models.CharField(max_length=20)
    price=models.IntegerField()
    category=models.ForeignKey(Category_flipkart,on_delete=models.CASCADE,default=1)
    description=models.CharField(max_length=200)
    image=models.ImageField(upload_to='image/')
    @staticmethod
    def get_all():
        return Product_flipkart.objects.all()
    @staticmethod
    def get_all_product_by_id(category_id):
        if category_id:
            return Product_flipkart.objects.filter(category_id=category_id)
        else:
            return Product_flipkart.get_all()

