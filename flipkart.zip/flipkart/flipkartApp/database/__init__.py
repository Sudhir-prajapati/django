from .category import Category_flipkart
from .product import Product_flipkart