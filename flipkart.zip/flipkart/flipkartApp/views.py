from django.shortcuts import render,redirect
from django.http import HttpResponse
from . database .product import Product_flipkart
from .database .category import Category_flipkart
from .database .user import Customer

# Create your views here.

def home(req):
    product=None
    category=Category_flipkart.get_all_category()
    categoryid=req.GET.get('x')
    if categoryid:
        product=Product_flipkart.get_all_product_by_id(categoryid)
    else:
        product=Product_flipkart.get_all()
    data={}
    data['key_product']=product
    data['key_category']=category
    return render(req,'index.html',data)
def signup(req):
    if(req.method == 'GET'):
        return render(req,'signup.html')
    
    else:
        name=req.POST.get('nm')
        password=req.POST.get('pass')
        email=req.POST.get('em')
        mobile=req.POST.get('mb')
        msg=None
        if(name==""):
            msg="please enter your name"
            return render(req,'signup.html',{"error":msg})
        elif(len(password)<=8):
            msg="password is too short password must be 8 char"
            return render(req,'signup.html',{"error":msg})
        else:
            customer=Customer(name=name,password=password,email=email,mobile=mobile)
            customer.register()
            return redirect('/login')
def login(req):
    if(req.method=='GET'):
        return render(req,'login.html')
    else:
        email=req.POST.get('em')
        password=req.POST.get('pass')
        if Customer.login_user(email,password):
            product=None
            category=Category_flipkart.get_all_category()
            categoryid=req.GET.get('x')
            if categoryid:
                product=Product_flipkart.get_all_product_by_id(categoryid)
            else:
                product=Product_flipkart.get_all()
            data={}
            data['key_product']=product
            data['key_category']=category
            data['key_email']=email
            data['key_password']=password
            return render(req,'profile.html',data)
        else:
            msg='login id or password not correct'
            return render(req,'login.html',{'error':msg})