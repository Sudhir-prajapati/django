from django.contrib import admin
from .database.category import Category_flipkart
from .database.product  import Product_flipkart
class Admin_product(admin.ModelAdmin):
    list_display=['name','price','category']

class Admin_category(admin.ModelAdmin):
    list_display=['name']


# Register your models here.
admin.site.register(Category_flipkart,Admin_category)
admin.site.register(Product_flipkart,Admin_product)
