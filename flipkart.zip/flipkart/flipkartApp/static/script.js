<script>
        window.addEventListener('scroll',function(){
            if(window.pageYOffset>200 && window.pageYOffset<300){
                document.getElementById('nav').style.background="black";
                document.getElementById('nav').style.background="white";
                document.body.style.background="blue";
                document.body.style.color="white";
            }else if(window.pageYOffset>300){
                document.getElementById('nav').style.background="green";
                document.getElementById('nav').style.color="yellow";
            }else{
                document.getElementById('nav').style.background="white";
                document.getElementById('nav').style.color="black";
            }
        })
    </script>